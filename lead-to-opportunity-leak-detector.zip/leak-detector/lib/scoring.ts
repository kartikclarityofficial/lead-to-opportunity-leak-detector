import { DiagnosticResult, Signal, Leak, Stage, Severity, HealthBand, StageHealth, Recommendation } from '@/types/diagnostic'
import { questions } from '@/data/questions'

const SCALE_VALUES: Record<number, number> = {
  0: 0,
  1: 25,
  2: 50,
  3: 75,
  4: 100,
}

export function calculateDiagnostic(answers: Record<string, any>): DiagnosticResult {
  const signals: Signal[] = Object.entries(answers).map(([questionId, answer]) => {
    const question = questions.find(q => q.id === questionId)
    if (!question) return null

    const numericValue = typeof answer === 'number' ? SCALE_VALUES[answer] : 50
    const impact = numericValue >= 75 ? 'positive' : numericValue <= 25 ? 'negative' : 'neutral'

    return {
      questionId,
      answer,
      impact,
      weight: question.weight,
    }
  }).filter(Boolean) as Signal[]

  const stageHealth: StageHealth[] = ['lead', 'qualification', 'conversation', 'meeting', 'opportunity'].map(stage => {
    const stageSignals = signals.filter(s => {
      const q = questions.find(q => q.id === s.questionId)
      return q?.stage === stage
    })

    const stageScore = calculateStageScore(stageSignals)

    return {
      stage: stage as Stage,
      score: stageScore,
      signals: stageSignals,
    }
  })

  const overallScore = Math.round(
    stageHealth.reduce((sum, sh) => sum + sh.score, 0) / stageHealth.length
  )

  const healthBand: HealthBand =
    overallScore >= 85 ? 'strong' :
    overallScore >= 70 ? 'healthy' :
    overallScore >= 50 ? 'leakage' : 'critical'

  const leaks = detectLeaks(stageHealth, signals)

  const primaryLeak = leaks.sort((a, b) => {
    const severityOrder = { critical: 4, high: 3, moderate: 2, low: 1 }
    return severityOrder[b.severity] - severityOrder[a.severity]
  })[0] || null

  const recommendations = generateRecommendations(leaks, stageHealth)

  return {
    overallScore,
    healthBand,
    leaks,
    primaryLeak,
    stageHealth,
    recommendations,
    signals,
  }
}

function calculateStageScore(signals: Signal[]): number {
  if (signals.length === 0) return 50

  const totalWeight = signals.reduce((sum, s) => sum + s.weight, 0)
  const weightedScore = signals.reduce((sum, s) => {
    const numericValue = typeof s.answer === 'number' ? SCALE_VALUES[s.answer] : 50
    return sum + (numericValue * s.weight)
  }, 0)

  return Math.round(weightedScore / totalWeight)
}

function detectLeaks(stageHealth: StageHealth[], signals: Signal[]): Leak[] {
  const leaks: Leak[] = []
  const stages: Stage[] = ['lead', 'qualification', 'conversation', 'meeting', 'opportunity']

  for (let i = 0; i < stages.length - 1; i++) {
    const currentStage = stageHealth[i]
    const nextStage = stageHealth[i + 1]

    const scoreDrop = currentStage.score - nextStage.score
    const avgScore = (currentStage.score + nextStage.score) / 2

    if (scoreDrop > 15 || avgScore < 60) {
      const severity: Severity =
        scoreDrop > 30 || avgScore < 40 ? 'critical' :
        scoreDrop > 20 || avgScore < 50 ? 'high' :
        scoreDrop > 10 || avgScore < 60 ? 'moderate' : 'low'

      const relevantSignals = [...currentStage.signals, ...nextStage.signals].filter(s => s.impact === 'negative')

      leaks.push({
        from: currentStage.stage,
        to: nextStage.stage,
        severity,
        signals: relevantSignals,
        explanation: generateLeakExplanation(currentStage.stage, nextStage.stage, severity),
        mechanism: generateLeakMechanism(currentStage.stage, nextStage.stage),
        implication: generateLeakImplication(currentStage.stage, nextStage.stage),
        recommendation: generateLeakRecommendation(currentStage.stage, nextStage.stage),
      })
    }
  }

  return leaks
}

function generateLeakExplanation(from: Stage, to: Stage, severity: Severity): string {
  const severityText = severity === 'critical' ? 'Critical momentum loss' :
                       severity === 'high' ? 'Significant friction' :
                       severity === 'moderate' ? 'Observable friction' : 'Minor friction'

  return `${severityText} detected between ${formatStage(from)} and ${formatStage(to)}. Qualified demand is not converting efficiently to the next stage.`
}

function generateLeakMechanism(from: Stage, to: Stage): string {
  const mechanisms: Record<string, string> = {
    'lead-qualification': 'Inconsistent lead qualification criteria or unclear ICP definition causing sales to engage with poor-fit prospects.',
    'qualification-conversation': 'Qualified leads not being contacted quickly enough, or initial outreach failing to establish value.',
    'conversation-meeting': 'Discovery conversations not producing concrete next steps or failing to establish urgency.',
    'meeting-opportunity': 'Meetings occurring with wrong stakeholders or without validated buying signals.',
  }

  return mechanisms[`${from}-${to}`] || 'Process friction preventing natural stage progression.'
}

function generateLeakImplication(from: Stage, to: Stage): string {
  const implications: Record<string, string> = {
    'lead-qualification': 'Sales capacity wasted on unqualified prospects. Pipeline appears healthy but contains low-quality opportunities.',
    'qualification-conversation': 'Qualified demand loses interest before sales engagement. Competitive disadvantage in fast-moving markets.',
    'conversation-meeting': 'Sales conversations fail to build urgency. Opportunities remain uncommitted and cycle time extends.',
    'meeting-opportunity': 'Meeting activity high but pipeline growth low. Inefficient use of prospect and sales time.',
  }

  return implications[`${from}-${to}`] || 'Revenue predictability and sales efficiency negatively impacted.'
}

function generateLeakRecommendation(from: Stage, to: Stage): string {
  const recommendations: Record<string, string> = {
    'lead-qualification': 'Standardize qualification criteria before sales acceptance',
    'qualification-conversation': 'Implement systematic rapid-response contact protocols',
    'conversation-meeting': 'Establish required next-step criteria for all discovery calls',
    'meeting-opportunity': 'Define validated buying signals required for opportunity creation',
  }

  return recommendations[`${from}-${to}`] || 'Review and standardize stage transition requirements'
}

function generateRecommendations(leaks: Leak[], stageHealth: StageHealth[]): Recommendation[] {
  const recommendations: Recommendation[] = []

  leaks.forEach(leak => {
    const priority = leak.severity === 'critical' ? 'critical' :
                    leak.severity === 'high' ? 'high' :
                    leak.severity === 'moderate' ? 'medium' : 'low'

    recommendations.push({
      action: leak.recommendation,
      why: leak.mechanism,
      priority,
      expectedEffect: `Reduce leakage between ${formatStage(leak.from)} and ${formatStage(leak.to)}`,
      firstMove: getFirstMove(leak.from, leak.to),
    })
  })

  stageHealth.forEach(sh => {
    if (sh.score < 60) {
      recommendations.push({
        action: `Strengthen ${formatStage(sh.stage)} stage processes`,
        why: `${formatStage(sh.stage)} diagnostic score indicates structural process weakness`,
        priority: sh.score < 40 ? 'critical' : sh.score < 50 ? 'high' : 'medium',
        expectedEffect: `Improve overall ${formatStage(sh.stage)} health and downstream conversion`,
        firstMove: getStageFirstMove(sh.stage),
      })
    }
  })

  const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 }
  return recommendations
    .sort((a, b) => priorityOrder[b.priority] - priorityOrder[a.priority])
    .slice(0, 5)
}

function getFirstMove(from: Stage, to: Stage): string {
  const firstMoves: Record<string, string> = {
    'lead-qualification': 'Document your ideal customer profile in a 5-point checklist. Require sales to confirm before accepting leads.',
    'qualification-conversation': 'Set a 4-hour maximum response time for qualified leads. Track and report violations.',
    'conversation-meeting': 'Create a required next-step field in your CRM. No conversation closes without it.',
    'meeting-opportunity': 'Define three mandatory buying signals. No opportunity created without all three validated.',
  }

  return firstMoves[`${from}-${to}`] || 'Audit current process and identify top 3 friction points.'
}

function getStageFirstMove(stage: Stage): string {
  const moves: Record<Stage, string> = {
    lead: 'Audit last 50 leads against your stated ICP criteria. Calculate match rate.',
    qualification: 'Review last 20 qualified opportunities. Identify which should have been disqualified.',
    conversation: 'Record next 10 discovery calls. Score them against a standardized framework.',
    meeting: 'Track meeting-to-opportunity conversion for each rep. Identify outliers.',
    opportunity: 'Review opportunities created in last 30 days. Validate buying signals were present.',
  }

  return moves[stage] || 'Audit current stage performance.'
}

function formatStage(stage: Stage): string {
  return stage.charAt(0).toUpperCase() + stage.slice(1)
}
