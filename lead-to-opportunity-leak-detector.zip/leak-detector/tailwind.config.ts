import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-inter)'],
      },
      colors: {
        neutral: {
          50: 'var(--neutral-50)',
          100: 'var(--neutral-100)',
          200: 'var(--neutral-200)',
          300: 'var(--neutral-300)',
          400: 'var(--neutral-400)',
          500: 'var(--neutral-500)',
          600: 'var(--neutral-600)',
          700: 'var(--neutral-700)',
          800: 'var(--neutral-800)',
          900: 'var(--neutral-900)',
          950: 'var(--neutral-950)',
        },
        strong: 'var(--color-strong)',
        healthy: 'var(--color-healthy)',
        watch: 'var(--color-watch)',
        leak: 'var(--color-leak)',
        critical: 'var(--color-critical)',
        signal: 'var(--color-signal)',
        evidence: 'var(--color-evidence)',
      },
      fontSize: {
        display: ['clamp(3rem, 8vw, 4.5rem)', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        h1: ['clamp(2rem, 5vw, 3.25rem)', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        h2: ['clamp(1.5rem, 3vw, 2.25rem)', { lineHeight: '1.3', letterSpacing: '-0.01em' }],
        h3: ['clamp(1.125rem, 2vw, 1.375rem)', { lineHeight: '1.4' }],
      },
    },
  },
  plugins: [],
}
export default config
