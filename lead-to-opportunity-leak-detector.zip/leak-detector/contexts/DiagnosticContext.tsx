'use client'

import { createContext, useContext, useState, ReactNode, useCallback } from 'react'
import { DiagnosticState, DiagnosticResult } from '@/types/diagnostic'
import { questions } from '@/data/questions'
import { calculateDiagnostic } from '@/lib/scoring'

interface DiagnosticContextType {
  state: DiagnosticState
  result: DiagnosticResult | null
  currentQuestion: number
  answerQuestion: (questionId: string, answer: any) => void
  nextQuestion: () => void
  previousQuestion: () => void
  resetDiagnostic: () => void
  completeDiagnostic: () => void
  startDiagnostic: () => void
}

const DiagnosticContext = createContext<DiagnosticContextType | undefined>(undefined)

export function DiagnosticProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<DiagnosticState>('idle')
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, any>>({})
  const [result, setResult] = useState<DiagnosticResult | null>(null)

  const startDiagnostic = useCallback(() => {
    setState('in-progress')
    setCurrentQuestion(0)
    setAnswers({})
    setResult(null)
  }, [])

  const answerQuestion = useCallback((questionId: string, answer: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }))
  }, [])

  const completeDiagnostic = useCallback(() => {
    setState('analyzing')

    setTimeout(() => {
      const diagnosticResult = calculateDiagnostic(answers)
      setResult(diagnosticResult)
      setState('complete')
    }, 1500)
  }, [answers])

  const nextQuestion = useCallback(() => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1)
    } else {
      completeDiagnostic()
    }
  }, [currentQuestion, completeDiagnostic])

  const previousQuestion = useCallback(() => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1)
    }
  }, [currentQuestion])

  const resetDiagnostic = useCallback(() => {
    setState('idle')
    setCurrentQuestion(0)
    setAnswers({})
    setResult(null)
  }, [])

  return (
    <DiagnosticContext.Provider
      value={{
        state,
        result,
        currentQuestion,
        answerQuestion,
        nextQuestion,
        previousQuestion,
        resetDiagnostic,
        completeDiagnostic,
        startDiagnostic,
      }}
    >
      {children}
    </DiagnosticContext.Provider>
  )
}

export function useDiagnostic() {
  const context = useContext(DiagnosticContext)
  if (!context) {
    throw new Error('useDiagnostic must be used within DiagnosticProvider')
  }
  return context
}
