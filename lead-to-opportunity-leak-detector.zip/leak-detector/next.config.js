/** @type {import('next').NextConfig} */

// GitHub Pages publishes this app under a repo subpath, not the domain root:
// https://kartikclarityofficial.github.io/lead-to-opportunity-leak-detector/
// Every asset/route reference must be prefixed accordingly. Setting basePath
// and assetPrefix here is the correct, single source of truth for that prefix
// across next/link, next/image, and generated <script>/<link> tags — nothing
// else in the app needs to hard-code the repo name.
const REPO_NAME = 'lead-to-opportunity-leak-detector'
const isGithubPagesBuild = process.env.GITHUB_PAGES === 'true'
const repoPathPrefix = isGithubPagesBuild ? `/${REPO_NAME}` : ''

const nextConfig = {
  reactStrictMode: true,

  // GitHub Pages serves static files only — there is no Node server to run
  // Next's default SSR/ISR output, so we statically export the whole app.
  output: 'export',

  // Required for `output: 'export'`: GitHub Pages has no image-optimization
  // endpoint, so next/image must skip server-side optimization entirely.
  images: {
    unoptimized: true,
  },

  basePath: repoPathPrefix,
  assetPrefix: repoPathPrefix,

  // GitHub Pages resolves `/some-route` to `some-route/index.html` only when
  // the URL has a trailing slash; without this, direct navigation to
  // sub-routes (e.g. /diagnostic) 404s on refresh even though the files exist.
  trailingSlash: true,
}

module.exports = nextConfig
