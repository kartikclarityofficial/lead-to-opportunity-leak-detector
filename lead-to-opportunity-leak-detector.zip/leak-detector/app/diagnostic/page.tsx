'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useDiagnostic } from '@/contexts/DiagnosticContext'
import { questions } from '@/data/questions'
import { ArrowRight, ArrowLeft } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function DiagnosticPage() {
  const { state, currentQuestion, answerQuestion, nextQuestion, previousQuestion, startDiagnostic } = useDiagnostic()
  const router = useRouter()
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)

  const question = questions[currentQuestion]
  const progress = ((currentQuestion + 1) / questions.length) * 100

  useEffect(() => {
    if (state === 'idle') {
      startDiagnostic()
    }
    if (state === 'complete') {
      router.push('/results')
    }
  }, [state, router, startDiagnostic])

  const handleAnswer = (answerIndex: number) => {
    setSelectedAnswer(answerIndex)
    answerQuestion(question.id, answerIndex)
  }

  const handleNext = () => {
    if (selectedAnswer !== null) {
      nextQuestion()
      setSelectedAnswer(null)
    }
  }

  const handlePrevious = () => {
    previousQuestion()
    setSelectedAnswer(null)
  }

  if (state === 'analyzing') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <motion.div
            className="w-16 h-16 border-2 border-neutral-900 border-t-transparent rounded-full mx-auto mb-6"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          />
          <p className="text-h3 font-medium text-neutral-900">Analyzing your diagnostic responses</p>
          <p className="text-neutral-500 mt-2">Detecting leakage patterns...</p>
        </motion.div>
      </div>
    )
  }

  if (!question) return null

  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="mb-12">
          <div className="flex items-center justify-between text-sm text-neutral-600 mb-2">
            <span>Question {currentQuestion + 1} of {questions.length}</span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <div className="h-1 bg-neutral-200 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-neutral-900"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={question.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-4">
              <span className="inline-block px-3 py-1 bg-neutral-100 text-neutral-600 text-xs font-medium uppercase tracking-wide rounded-sm">
                {question.stage}
              </span>
            </div>

            <h2 className="text-h2 font-bold mb-4">
              {question.text}
            </h2>

            <p className="text-neutral-600 mb-8 leading-relaxed">
              {question.context}
            </p>

            <div className="space-y-3 mb-12">
              {question.options?.map((option, index) => (
                <motion.button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  className={`
                    w-full px-6 py-4 text-left rounded-sm border-2 transition-all
                    ${selectedAnswer === index
                      ? 'border-neutral-900 bg-neutral-900 text-white'
                      : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }
                  `}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{option}</span>
                    <div className={`
                      w-5 h-5 rounded-full border-2 transition-colors
                      ${selectedAnswer === index
                        ? 'border-white bg-white'
                        : 'border-neutral-300'
                      }
                    `}>
                      {selectedAnswer === index && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-full h-full bg-neutral-900 rounded-full scale-50"
                        />
                      )}
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>

            {selectedAnswer !== null && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-8 p-4 bg-signal/5 border border-signal/20 rounded-sm"
              >
                <p className="text-sm text-signal font-medium">Signal detected</p>
              </motion.div>
            )}

            <div className="flex items-center justify-between pt-8 border-t border-neutral-200">
              <button
                onClick={handlePrevious}
                disabled={currentQuestion === 0}
                className="flex items-center gap-2 px-6 py-3 text-neutral-600 hover:text-neutral-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                Previous
              </button>

              <button
                onClick={handleNext}
                disabled={selectedAnswer === null}
                className="flex items-center gap-2 px-8 py-3 bg-neutral-900 text-white rounded-sm hover:bg-neutral-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                {currentQuestion === questions.length - 1 ? 'Complete Diagnostic' : 'Next Question'}
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}
