'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useDiagnostic } from '@/contexts/DiagnosticContext'
import { motion } from 'framer-motion'
import { DiagnosticPath } from '@/components/DiagnosticPath'
import { AlertTriangle, ArrowRight, TrendingDown } from 'lucide-react'

export default function ResultsPage() {
  const { result, state, resetDiagnostic } = useDiagnostic()
  const router = useRouter()

  useEffect(() => {
    if (state !== 'complete' || !result) {
      router.push('/')
    }
  }, [state, result, router])

  if (!result) return null

  const getHealthBandColor = (band: string) => {
    switch (band) {
      case 'strong': return 'text-strong'
      case 'healthy': return 'text-healthy'
      case 'leakage': return 'text-leak'
      case 'critical': return 'text-critical'
      default: return 'text-neutral-900'
    }
  }

  const getHealthBandLabel = (band: string) => {
    switch (band) {
      case 'strong': return 'Strong'
      case 'healthy': return 'Healthy with friction'
      case 'leakage': return 'Leakage detected'
      case 'critical': return 'Critical leakage'
      default: return band
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-critical bg-critical/10 border-critical'
      case 'high': return 'text-leak bg-leak/10 border-leak'
      case 'moderate': return 'text-watch bg-watch/10 border-watch'
      case 'low': return 'text-healthy bg-healthy/10 border-healthy'
      default: return 'text-neutral-600 bg-neutral-100 border-neutral-200'
    }
  }

  return (
    <div className="min-h-screen py-12 px-4 pb-24 md:pb-12">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-h1 font-bold mb-4">
            Lead-to-Opportunity Diagnostic
          </h1>
          <p className="text-neutral-600">
            Your diagnostic analysis is complete
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-16 text-center"
        >
          <div className="mb-2 text-sm font-medium text-neutral-500 uppercase tracking-wide">
            Lead-to-Opportunity Health
          </div>
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3, type: 'spring' }}
            className={`text-[120px] leading-none font-bold ${getHealthBandColor(result.healthBand)}`}
          >
            {result.overallScore}
          </motion.div>
          <div className="text-h3 font-medium text-neutral-600 mt-4">
            {getHealthBandLabel(result.healthBand)}
          </div>
        </motion.div>

        {result.primaryLeak && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-16 p-8 border-2 border-leak bg-leak/5 rounded-sm"
          >
            <div className="flex items-start gap-4">
              <AlertTriangle className="w-6 h-6 text-leak flex-shrink-0 mt-1" />
              <div className="flex-1">
                <div className="text-sm font-medium text-leak uppercase tracking-wide mb-2">
                  Primary Leak Detected
                </div>
                <div className="text-h3 font-bold mb-4">
                  {result.primaryLeak.from.charAt(0).toUpperCase() + result.primaryLeak.from.slice(1)} → {result.primaryLeak.to.charAt(0).toUpperCase() + result.primaryLeak.to.slice(1)}
                </div>
                <p className="text-neutral-700 mb-4">
                  {result.primaryLeak.explanation}
                </p>
                <div className={`inline-flex items-center gap-2 px-3 py-1 border rounded-sm text-sm font-medium ${getSeverityColor(result.primaryLeak.severity)}`}>
                  <TrendingDown className="w-4 h-4" />
                  {result.primaryLeak.severity.toUpperCase()} SEVERITY
                </div>
              </div>
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mb-16"
        >
          <h2 className="text-h2 font-bold mb-8 text-center">Diagnostic Map</h2>
          <DiagnosticPath interactive={false} />
        </motion.div>

        {result.leaks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mb-16"
          >
            <h2 className="text-h2 font-bold mb-8">Detected Leaks</h2>
            <div className="space-y-6">
              {result.leaks.map((leak, index) => (
                <div key={index} className="border border-neutral-200 rounded-sm overflow-hidden">
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="text-h3 font-bold mb-2">
                          {leak.from.charAt(0).toUpperCase() + leak.from.slice(1)} → {leak.to.charAt(0).toUpperCase() + leak.to.slice(1)}
                        </div>
                        <div className={`inline-flex items-center gap-2 px-3 py-1 border rounded-sm text-xs font-medium ${getSeverityColor(leak.severity)}`}>
                          {leak.severity.toUpperCase()}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="text-sm font-semibold text-neutral-900 mb-1">What this means</div>
                        <p className="text-neutral-600">{leak.explanation}</p>
                      </div>

                      <div>
                        <div className="text-sm font-semibold text-neutral-900 mb-1">Likely mechanism</div>
                        <p className="text-neutral-600">{leak.mechanism}</p>
                      </div>

                      <div>
                        <div className="text-sm font-semibold text-neutral-900 mb-1">Business implication</div>
                        <p className="text-neutral-600">{leak.implication}</p>
                      </div>

                      <div className="pt-4 border-t border-neutral-200">
                        <div className="text-sm font-semibold text-neutral-900 mb-1">Evidence</div>
                        <p className="text-sm text-neutral-500">{leak.signals.length} signals contributed to this diagnosis</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {result.recommendations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="mb-16"
          >
            <h2 className="text-h2 font-bold mb-8">Recommended Actions</h2>
            <div className="space-y-4">
              {result.recommendations.map((rec, index) => (
                <div key={index} className="p-6 bg-white border border-neutral-200 rounded-sm">
                  <div className="flex items-start justify-between mb-4">
                    <div className="text-h3 font-bold flex-1">
                      {rec.action}
                    </div>
                    <div className={`
                      px-3 py-1 text-xs font-medium uppercase tracking-wide rounded-sm flex-shrink-0 ml-4
                      ${rec.priority === 'critical' ? 'bg-critical/10 text-critical' :
                        rec.priority === 'high' ? 'bg-leak/10 text-leak' :
                        rec.priority === 'medium' ? 'bg-watch/10 text-watch' :
                        'bg-neutral-100 text-neutral-600'
                      }
                    `}>
                      {rec.priority}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="text-sm font-semibold text-neutral-900 mb-1">Why</div>
                      <p className="text-neutral-600">{rec.why}</p>
                    </div>

                    <div>
                      <div className="text-sm font-semibold text-neutral-900 mb-1">Expected effect</div>
                      <p className="text-neutral-600">{rec.expectedEffect}</p>
                    </div>

                    <div className="pt-3 border-t border-neutral-200">
                      <div className="text-sm font-semibold text-neutral-900 mb-1">First move</div>
                      <p className="text-neutral-700 font-medium">{rec.firstMove}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mb-16 p-8 bg-neutral-900 text-white rounded-sm"
        >
          <p className="text-neutral-400 text-sm mb-2">Diagnostic Insight</p>
          <p className="text-h3 leading-relaxed">
            Your funnel isn't necessarily short on leads. The diagnostic indicates that the larger issue may be what happens after {result.primaryLeak ? result.primaryLeak.from : 'qualification'}.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <button
            onClick={resetDiagnostic}
            className="px-8 py-4 border border-neutral-300 text-neutral-900 rounded-sm font-medium hover:border-neutral-400 transition-colors"
          >
            Run New Diagnostic
          </button>
          <button
            onClick={() => window.print()}
            className="px-8 py-4 bg-neutral-900 text-white rounded-sm font-medium hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2"
          >
            Export Report
            <ArrowRight className="w-5 h-5" />
          </button>
        </motion.div>
      </div>
    </div>
  )
}
