import './globals.css'
import { Inter } from 'next/font/google'
import { AppShell } from '@/components/AppShell'
import { DiagnosticProvider } from '@/contexts/DiagnosticContext'
import { CommandPalette } from '@/components/CommandPalette'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata = {
  title: 'Lead-to-Opportunity Leak Detector™',
  description: 'Find where qualified demand disappears before it becomes pipeline.',
  icons: {
    icon: '/logo-circle.svg',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="antialiased bg-neutral-50 text-neutral-900">
        <DiagnosticProvider>
          <AppShell>
            {children}
          </AppShell>
          <CommandPalette />
        </DiagnosticProvider>
      </body>
    </html>
  )
}
