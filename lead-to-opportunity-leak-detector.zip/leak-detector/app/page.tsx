import Hero from '@/components/Hero'
import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Lead-to-Opportunity Leak Detector™',
  description: 'Find where qualified demand disappears before it becomes pipeline.',
}

export default function HomePage() {
  return <Hero />
}
