'use client'

import { motion } from 'framer-motion'
import { Target, Activity, Search, Zap, TrendingUp } from 'lucide-react'

export default function MethodPage() {
  return (
    <div className="min-h-screen py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-h1 font-bold mb-4">
            The Method
          </h1>
          <p className="text-h3 text-neutral-600 max-w-2xl mx-auto">
            How the Lead-to-Opportunity Leak Detector identifies hidden revenue loss
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="prose prose-lg max-w-none"
        >
          <div className="space-y-12">
            <div>
              <h2 className="text-h2 font-bold mb-4">The Problem</h2>
              <p className="text-neutral-600 leading-relaxed">
                Most revenue teams track conversion rates between major funnel stages. But conversion rates alone don't reveal <em>why</em> qualified leads disappear. They don't show you where process breaks down, where handoffs fail, or where qualification standards weaken.
              </p>
              <p className="text-neutral-600 leading-relaxed mt-4">
                The Lead-to-Opportunity Leak Detector™ goes deeper. It examines the operational mechanics between stages to identify specific points where momentum is lost.
              </p>
            </div>

            <div className="p-8 bg-neutral-50 border border-neutral-200 rounded-sm">
              <h3 className="text-h3 font-bold mb-6">The Five-Stage Journey</h3>
              <div className="space-y-6">
                {[
                  { icon: Target, stage: 'Lead', description: 'Raw demand enters your system' },
                  { icon: Search, stage: 'Qualification', description: 'Demand is validated against ICP criteria' },
                  { icon: Activity, stage: 'Conversation', description: 'Sales engages and establishes value' },
                  { icon: Zap, stage: 'Meeting', description: 'Stakeholders commit time' },
                  { icon: TrendingUp, stage: 'Opportunity', description: 'Validated buying intent creates pipeline' },
                ].map((item, index) => {
                  const Icon = item.icon
                  return (
                    <div key={index} className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-white border border-neutral-200 rounded-sm flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-neutral-700" />
                      </div>
                      <div>
                        <div className="font-bold text-neutral-900">{item.stage}</div>
                        <div className="text-neutral-600">{item.description}</div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            <div>
              <h2 className="text-h2 font-bold mb-4">How It Works</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-h3 font-semibold mb-2">1. Diagnostic Assessment</h3>
                  <p className="text-neutral-600 leading-relaxed">
                    A structured series of questions examines process quality, speed, standardization, and signal validation at each stage.
                  </p>
                </div>

                <div>
                  <h3 className="text-h3 font-semibold mb-2">2. Signal Collection</h3>
                  <p className="text-neutral-600 leading-relaxed">
                    Each response generates a diagnostic signal. Signals are weighted based on their predictive importance for stage health.
                  </p>
                </div>

                <div>
                  <h3 className="text-h3 font-semibold mb-2">3. Stage Health Calculation</h3>
                  <p className="text-neutral-600 leading-relaxed">
                    Signals within each stage combine to produce a stage health score (0-100). This reflects process maturity and execution quality.
                  </p>
                </div>

                <div>
                  <h3 className="text-h3 font-semibold mb-2">4. Leak Detection</h3>
                  <p className="text-neutral-600 leading-relaxed">
                    The system identifies transitions where stage health drops significantly or where average health falls below threshold. These are classified as leaks.
                  </p>
                </div>

                <div>
                  <h3 className="text-h3 font-semibold mb-2">5. Evidence Mapping</h3>
                  <p className="text-neutral-600 leading-relaxed">
                    Each leak is connected to the specific responses that triggered it, creating a transparent evidence trail.
                  </p>
                </div>

                <div>
                  <h3 className="text-h3 font-semibold mb-2">6. Recommendation Generation</h3>
                  <p className="text-neutral-600 leading-relaxed">
                    Based on leak severity and stage weakness, the system generates prioritized, actionable recommendations with specific first moves.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-8 bg-neutral-900 text-white rounded-sm">
              <h3 className="text-h3 font-bold mb-4">What Makes This Different</h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0" />
                  <span>Diagnostic focus on <em>why</em> leaks occur, not just that they exist</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0" />
                  <span>Evidence-based findings connected to specific operational signals</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0" />
                  <span>Severity classification helps prioritize limited improvement capacity</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0" />
                  <span>Actionable recommendations with concrete first moves</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 bg-white rounded-full mt-2 flex-shrink-0" />
                  <span>No CRM integration required—diagnostic runs independently</span>
                </li>
              </ul>
            </div>

            <div>
              <h2 className="text-h2 font-bold mb-4">Important Limitations</h2>
              <p className="text-neutral-600 leading-relaxed mb-4">
                This diagnostic is <strong>not</strong> a predictive model. It does not analyze actual CRM data. It does not guarantee specific revenue outcomes.
              </p>
              <p className="text-neutral-600 leading-relaxed">
                It is a <strong>structured assessment framework</strong> that helps revenue leaders systematically examine process health and identify likely friction points based on established sales methodology principles.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
