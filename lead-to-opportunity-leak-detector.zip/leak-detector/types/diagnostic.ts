export type DiagnosticState = 'idle' | 'in-progress' | 'analyzing' | 'complete'

export type Stage = 'lead' | 'qualification' | 'conversation' | 'meeting' | 'opportunity'

export type Severity = 'low' | 'moderate' | 'high' | 'critical'

export type HealthBand = 'strong' | 'healthy' | 'leakage' | 'critical'

export interface Question {
  id: string
  stage: Stage
  text: string
  context: string
  type: 'boolean' | 'scale' | 'select'
  options?: string[]
  weight: number
}

export interface Signal {
  questionId: string
  answer: any
  impact: 'positive' | 'negative' | 'neutral'
  weight: number
}

export interface Leak {
  from: Stage
  to: Stage
  severity: Severity
  signals: Signal[]
  explanation: string
  mechanism: string
  implication: string
  recommendation: string
}

export interface StageHealth {
  stage: Stage
  score: number
  signals: Signal[]
}

export interface Recommendation {
  action: string
  why: string
  priority: 'low' | 'medium' | 'high' | 'critical'
  expectedEffect: string
  firstMove: string
}

export interface DiagnosticResult {
  overallScore: number
  healthBand: HealthBand
  leaks: Leak[]
  primaryLeak: Leak | null
  stageHealth: StageHealth[]
  recommendations: Recommendation[]
  signals: Signal[]
}
