# Lead-to-Opportunity Leak Detector™

A premium revenue diagnostic instrument that finds where qualified demand
disappears before it becomes pipeline.

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Framer Motion
- lucide-react

## Structure

- `app/` — routes (`/`, `/diagnostic`, `/results`, `/method`)
- `components/` — UI components (Hero, AppShell, CommandPalette, DiagnosticPath)
- `contexts/` — diagnostic state (`DiagnosticContext`)
- `lib/scoring.ts` — deterministic scoring engine (no black-box AI)
- `data/questions.ts` — the 17-question diagnostic bank
- `types/diagnostic.ts` — shared types
- `public/logo-circle.svg` — mark (favicon / avatar use)
- `public/logo-rectangle.svg` — full wordmark lockup (header / OG use)

## Deploying to GitHub Pages

This repo is configured to publish as a **static export** at a repo subpath
(`https://<user>.github.io/lead-to-opportunity-leak-detector/`), built and
deployed automatically by `.github/workflows/deploy.yml` on every push to
`main`.

1. Unzip this archive, then from inside `leak-detector/`:
   ```bash
   git init && git add . && git commit -m "Initial commit"
   git remote add origin <your-repo-url>
   git branch -M main
   git push -u origin main
   ```
2. **One-time repo setting (required — cannot be done from a workflow file):**
   in the repo, go to **Settings → Pages → Build and deployment → Source**,
   and select **"GitHub Actions"** (not "Deploy from a branch"). Without this,
   Pages ignores the workflow's deployment entirely and keeps 404ing.
3. Push to `main` (or re-run the workflow manually from the **Actions** tab).
   The workflow builds with `next build` (static export via `output: 'export'`
   in `next.config.js`), verifies `out/index.html` exists, and deploys `out/`
   via the official `actions/deploy-pages` action.
4. The site becomes available at:
   `https://<your-github-username>.github.io/lead-to-opportunity-leak-detector/`

### Why the config looks the way it does

- `next.config.js` sets `output: 'export'` (GitHub Pages has no Node server
  to run Next's default SSR output), `images.unoptimized: true` (no
  image-optimization endpoint on static hosting), `basePath`/`assetPrefix`
  of `/lead-to-opportunity-leak-detector` (the app is served from a repo
  subpath, not the domain root), and `trailingSlash: true` (so GitHub Pages
  resolves `/diagnostic` to `/diagnostic/index.html` on direct navigation
  and refresh, not just client-side routing).
- `public/.nojekyll` stops GitHub Pages' default Jekyll processing from
  silently dropping the `_next/` output folder (Jekyll ignores
  underscore-prefixed paths by default).
- The `basePath`/`assetPrefix` only apply when `GITHUB_PAGES=true` (set by
  the workflow), so `npm run dev` locally still serves from `/` with no
  extra steps.

## Running locally / deploying elsewhere

```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000). To deploy to Vercel or
any Node host instead of GitHub Pages, remove `output: 'export'` (and the
`basePath`/`assetPrefix`/`images.unoptimized` lines) from `next.config.js`
first — those are GitHub-Pages-specific and would otherwise disable
server-side features and misroute assets on a root domain.
