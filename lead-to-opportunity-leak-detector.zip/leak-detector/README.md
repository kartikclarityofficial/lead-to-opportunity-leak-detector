# Lead-to-Opportunity Leak Detector™

A premium revenue diagnostic instrument that finds where qualified demand
disappears before it becomes pipeline.

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Stack

- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Framer Motion
- lucide-react

## Structure

- `app/` — routes (`/`, `/diagnostic`, `/results`, `/method`)
- `components/` — UI components (Hero, AppShell, CommandPalette, DiagnosticPath)
- `contexts/` — diagnostic state (`DiagnosticContext`)
- `lib/scoring.ts` — deterministic scoring engine (no black-box AI)
- `data/questions.ts` — the 17-question diagnostic bank
- `types/diagnostic.ts` — shared types
- `public/logo-circle.svg` — mark (favicon / avatar use)
- `public/logo-rectangle.svg` — full wordmark lockup (header / OG use)

## Deploying to GitHub

1. Unzip this archive.
2. `git init && git add . && git commit -m "Initial commit"`
3. Create a new GitHub repo and push:
   ```bash
   git remote add origin <your-repo-url>
   git branch -M main
   git push -u origin main
   ```
4. Import the repo into Vercel (or run `npm run build && npm start` anywhere
   that supports Next.js).
