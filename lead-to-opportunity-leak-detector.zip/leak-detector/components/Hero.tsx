'use client'

import { motion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import { useDiagnostic } from '@/contexts/DiagnosticContext'
import { useRouter } from 'next/navigation'
import { DiagnosticPath } from './DiagnosticPath'

export default function Hero() {
  const { startDiagnostic } = useDiagnostic()
  const router = useRouter()

  const handleStartDiagnostic = () => {
    startDiagnostic()
    router.push('/diagnostic')
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="max-w-6xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-display font-bold tracking-tight mb-6">
            LEAD → OPPORTUNITY
          </h1>

          <p className="text-h2 text-neutral-600 max-w-3xl mx-auto mb-12">
            Find where qualified demand disappears before it becomes pipeline.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <motion.button
              onClick={handleStartDiagnostic}
              className="group px-8 py-4 bg-neutral-900 text-white rounded-sm font-medium text-lg hover:bg-neutral-800 transition-colors flex items-center gap-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Run the Diagnostic
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>

            <motion.button
              onClick={() => router.push('/method')}
              className="px-8 py-4 border border-neutral-300 text-neutral-900 rounded-sm font-medium text-lg hover:border-neutral-400 transition-colors"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Explore the Method
            </motion.button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <DiagnosticPath interactive={false} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <p className="text-neutral-500 text-sm mb-4">
            Your CRM tells you what happened.
          </p>
          <p className="text-neutral-900 font-medium text-lg">
            This tells you where opportunity is leaking.
          </p>
        </motion.div>
      </div>
    </div>
  )
}
