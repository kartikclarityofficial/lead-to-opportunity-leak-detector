'use client'

import { useEffect, useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, ArrowRight } from 'lucide-react'
import { useDiagnostic } from '@/contexts/DiagnosticContext'

export function CommandPalette() {
  const [isOpen, setIsOpen] = useState(false)
  const [search, setSearch] = useState('')
  const router = useRouter()
  const { startDiagnostic, resetDiagnostic, state } = useDiagnostic()

  const commands = [
    { id: 'run-diagnostic', label: 'Run diagnostic', action: () => { startDiagnostic(); router.push('/diagnostic') }, shortcut: 'D' },
    { id: 'view-results', label: 'View results', action: () => router.push('/results'), shortcut: 'R', disabled: state !== 'complete' },
    { id: 'reset', label: 'Reset assessment', action: resetDiagnostic, shortcut: 'X' },
    { id: 'method', label: 'Explore the method', action: () => router.push('/method'), shortcut: 'M' },
    { id: 'home', label: 'Go to overview', action: () => router.push('/'), shortcut: 'H' },
  ]

  const filteredCommands = commands.filter(cmd =>
    cmd.label.toLowerCase().includes(search.toLowerCase())
  )

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        setIsOpen(prev => !prev)
      }
      if (e.key === 'Escape') {
        setIsOpen(false)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  const handleCommand = useCallback((action: () => void) => {
    action()
    setIsOpen(false)
    setSearch('')
  }, [])

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-neutral-900/50 backdrop-blur-sm z-50 flex items-start justify-center pt-[20vh] px-4"
        onClick={() => setIsOpen(false)}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl bg-white rounded-sm shadow-2xl overflow-hidden"
        >
          <div className="flex items-center gap-3 px-4 py-4 border-b border-neutral-200">
            <Search className="w-5 h-5 text-neutral-400" />
            <input
              type="text"
              placeholder="Search commands..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 outline-none text-neutral-900 placeholder:text-neutral-400"
              autoFocus
            />
            <kbd className="px-2 py-1 text-xs bg-neutral-100 text-neutral-600 rounded">ESC</kbd>
          </div>

          <div className="max-h-96 overflow-y-auto">
            {filteredCommands.map((cmd, index) => (
              <button
                key={cmd.id}
                onClick={() => !cmd.disabled && handleCommand(cmd.action)}
                disabled={cmd.disabled}
                className={`
                  w-full flex items-center justify-between px-4 py-3 text-left transition-colors
                  ${cmd.disabled
                    ? 'text-neutral-400 cursor-not-allowed'
                    : 'hover:bg-neutral-50 text-neutral-900'
                  }
                  ${index !== 0 ? 'border-t border-neutral-100' : ''}
                `}
              >
                <span className="font-medium">{cmd.label}</span>
                <div className="flex items-center gap-2">
                  {cmd.shortcut && (
                    <kbd className="px-2 py-1 text-xs bg-neutral-100 text-neutral-600 rounded">
                      {cmd.shortcut}
                    </kbd>
                  )}
                  <ArrowRight className="w-4 h-4 text-neutral-400" />
                </div>
              </button>
            ))}
          </div>

          <div className="px-4 py-3 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between text-xs text-neutral-500">
            <span>Navigate with arrow keys</span>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-white border border-neutral-200 rounded text-[10px]">⌘</kbd>
                <kbd className="px-1.5 py-0.5 bg-white border border-neutral-200 rounded text-[10px]">K</kbd>
                <span className="ml-1">to toggle</span>
              </span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
