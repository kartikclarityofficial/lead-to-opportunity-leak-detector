'use client'

import { ReactNode } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { Home, Activity, Layers, FileText, BarChart3 } from 'lucide-react'
import { useDiagnostic } from '@/contexts/DiagnosticContext'
import Image from 'next/image'

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const { state } = useDiagnostic()

  const navigation = [
    { name: 'Overview', href: '/', icon: Home },
    { name: 'Diagnostic', href: '/diagnostic', icon: Activity },
    { name: 'Results', href: '/results', icon: BarChart3, disabled: state !== 'complete' },
    { name: 'Method', href: '/method', icon: FileText },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Navigation */}
      <header className="border-b border-neutral-200 bg-white/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <button
              onClick={() => router.push('/')}
              className="flex items-center gap-3 hover:opacity-80 transition-opacity"
            >
              <Image src="/logo-circle.svg" alt="" width={32} height={32} className="w-8 h-8" priority />
              <span className="font-semibold text-sm hidden sm:block">
                Leak Detector™
              </span>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {navigation.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href
                const isDisabled = item.disabled

                return (
                  <button
                    key={item.name}
                    onClick={() => !isDisabled && router.push(item.href)}
                    disabled={isDisabled}
                    className={`
                      px-4 py-2 rounded-sm text-sm font-medium transition-colors flex items-center gap-2
                      ${isActive
                        ? 'bg-neutral-900 text-white'
                        : isDisabled
                        ? 'text-neutral-400 cursor-not-allowed'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                      }
                    `}
                  >
                    <Icon className="w-4 h-4" />
                    {item.name}
                  </button>
                )
              })}
            </nav>

            {/* Mobile Menu Button */}
            <button className="md:hidden p-2 text-neutral-600">
              <Layers className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-200 bg-white mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col items-center justify-center gap-6">
            <Image src="/logo-rectangle.svg" alt="Lead-to-Opportunity Leak Detector" width={260} height={56} className="h-10 w-auto" />
            <p className="text-sm text-neutral-500 text-center max-w-md">
              A premium revenue diagnostic instrument.
              <br />
              Find where qualified demand disappears.
            </p>
            <div className="flex gap-6 text-xs text-neutral-400">
              <button className="hover:text-neutral-600 transition-colors">Method</button>
              <button className="hover:text-neutral-600 transition-colors">Privacy</button>
              <button className="hover:text-neutral-600 transition-colors">Terms</button>
            </div>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 z-40">
        <nav className="flex items-center justify-around">
          {navigation.slice(0, 4).map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            const isDisabled = item.disabled

            return (
              <button
                key={item.name}
                onClick={() => !isDisabled && router.push(item.href)}
                disabled={isDisabled}
                className={`
                  flex-1 py-3 flex flex-col items-center gap-1 text-xs transition-colors
                  ${isActive
                    ? 'text-neutral-900'
                    : isDisabled
                    ? 'text-neutral-300'
                    : 'text-neutral-500'
                  }
                `}
              >
                <Icon className="w-5 h-5" />
                <span>{item.name}</span>
              </button>
            )
          })}
        </nav>
      </div>
    </div>
  )
}
