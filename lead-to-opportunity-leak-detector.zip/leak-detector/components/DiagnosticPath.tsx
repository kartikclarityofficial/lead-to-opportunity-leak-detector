'use client'

import { motion } from 'framer-motion'
import { useDiagnostic } from '@/contexts/DiagnosticContext'
import { Stage } from '@/types/diagnostic'
import { AlertTriangle, CheckCircle2, AlertCircle } from 'lucide-react'

interface DiagnosticPathProps {
  interactive?: boolean
}

export function DiagnosticPath({ interactive = false }: DiagnosticPathProps) {
  const { result } = useDiagnostic()

  const stages: { id: Stage; label: string }[] = [
    { id: 'lead', label: 'LEAD' },
    { id: 'qualification', label: 'QUALIFICATION' },
    { id: 'conversation', label: 'CONVERSATION' },
    { id: 'meeting', label: 'MEETING' },
    { id: 'opportunity', label: 'OPPORTUNITY' },
  ]

  const getStageStatus = (stage: Stage) => {
    if (!result) return 'default'

    const stageHealth = result.stageHealth.find(sh => sh.stage === stage)
    if (!stageHealth) return 'default'

    const hasLeakFrom = result.leaks.some(leak => leak.from === stage)
    const hasLeakTo = result.leaks.some(leak => leak.to === stage)

    if (hasLeakFrom || hasLeakTo) return 'leak'
    if (stageHealth.score >= 75) return 'strong'
    if (stageHealth.score >= 60) return 'healthy'
    return 'watch'
  }

  const getConnectionStatus = (fromStage: Stage, toStage: Stage) => {
    if (!result) return 'default'

    const leak = result.leaks.find(l => l.from === fromStage && l.to === toStage)
    if (!leak) return 'healthy'

    return leak.severity
  }

  return (
    <div className="w-full py-12">
      {/* Desktop: Horizontal */}
      <div className="hidden md:flex items-center justify-center gap-0">
        {stages.map((stage, index) => {
          const status = getStageStatus(stage.id)
          const nextStage = stages[index + 1]
          const connectionStatus = nextStage ? getConnectionStatus(stage.id, nextStage.id) : null

          return (
            <div key={stage.id} className="flex items-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`
                  relative px-6 py-4 min-w-[160px] text-center
                  ${status === 'leak' ? 'bg-leak/10 border-2 border-leak' :
                    status === 'strong' ? 'bg-strong/5 border border-strong/20' :
                    status === 'healthy' ? 'bg-neutral-100 border border-neutral-200' :
                    status === 'watch' ? 'bg-watch/5 border border-watch/20' :
                    'bg-white border border-neutral-200'}
                  ${interactive ? 'cursor-pointer hover:shadow-lg transition-shadow' : ''}
                `}
              >
                <div className="text-xs font-medium text-neutral-500 mb-1">
                  {String(index + 1).padStart(2, '0')}
                </div>
                <div className="font-semibold text-sm tracking-wide">
                  {stage.label}
                </div>

                {result && (
                  <div className="mt-2 flex items-center justify-center gap-1">
                    {status === 'leak' && <AlertTriangle className="w-4 h-4 text-leak" />}
                    {status === 'strong' && <CheckCircle2 className="w-4 h-4 text-strong" />}
                    {status === 'watch' && <AlertCircle className="w-4 h-4 text-watch" />}
                    <span className="text-xs font-medium">
                      {result.stageHealth.find(sh => sh.stage === stage.id)?.score ?? '--'}
                    </span>
                  </div>
                )}
              </motion.div>

              {nextStage && (
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: index * 0.1 + 0.05 }}
                  className="flex items-center justify-center"
                  style={{ originX: 0 }}
                >
                  {connectionStatus === 'critical' || connectionStatus === 'high' ? (
                    <div className="w-16 h-[2px] bg-gradient-to-r from-leak to-transparent relative">
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                        <div className="w-2 h-2 bg-leak rotate-45" />
                      </div>
                    </div>
                  ) : connectionStatus === 'moderate' ? (
                    <div className="w-16 h-[2px] bg-gradient-to-r from-watch to-neutral-300" />
                  ) : connectionStatus === 'healthy' ? (
                    <div className="w-16 h-[2px] bg-neutral-300" />
                  ) : (
                    <div className="w-16 h-[2px] bg-neutral-200" />
                  )}
                </motion.div>
              )}
            </div>
          )
        })}
      </div>

      {/* Mobile: Vertical */}
      <div className="md:hidden flex flex-col items-center gap-0">
        {stages.map((stage, index) => {
          const status = getStageStatus(stage.id)
          const nextStage = stages[index + 1]
          const connectionStatus = nextStage ? getConnectionStatus(stage.id, nextStage.id) : null

          return (
            <div key={stage.id} className="flex flex-col items-center w-full max-w-xs">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`
                  w-full px-6 py-4 text-center
                  ${status === 'leak' ? 'bg-leak/10 border-2 border-leak' :
                    status === 'strong' ? 'bg-strong/5 border border-strong/20' :
                    status === 'healthy' ? 'bg-neutral-100 border border-neutral-200' :
                    status === 'watch' ? 'bg-watch/5 border border-watch/20' :
                    'bg-white border border-neutral-200'}
                `}
              >
                <div className="text-xs font-medium text-neutral-500 mb-1">
                  {String(index + 1).padStart(2, '0')}
                </div>
                <div className="font-semibold text-sm tracking-wide">
                  {stage.label}
                </div>

                {result && (
                  <div className="mt-2 flex items-center justify-center gap-1">
                    {status === 'leak' && <AlertTriangle className="w-4 h-4 text-leak" />}
                    {status === 'strong' && <CheckCircle2 className="w-4 h-4 text-strong" />}
                    {status === 'watch' && <AlertCircle className="w-4 h-4 text-watch" />}
                    <span className="text-xs font-medium">
                      {result.stageHealth.find(sh => sh.stage === stage.id)?.score ?? '--'}
                    </span>
                  </div>
                )}
              </motion.div>

              {nextStage && (
                <motion.div
                  initial={{ scaleY: 0 }}
                  animate={{ scaleY: 1 }}
                  transition={{ delay: index * 0.1 + 0.05 }}
                  className="flex items-center justify-center py-2"
                  style={{ originY: 0 }}
                >
                  {connectionStatus === 'critical' || connectionStatus === 'high' ? (
                    <div className="h-8 w-[2px] bg-gradient-to-b from-leak to-transparent relative">
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                        <div className="w-2 h-2 bg-leak rotate-45" />
                      </div>
                    </div>
                  ) : connectionStatus === 'moderate' ? (
                    <div className="h-8 w-[2px] bg-gradient-to-b from-watch to-neutral-300" />
                  ) : connectionStatus === 'healthy' ? (
                    <div className="h-8 w-[2px] bg-neutral-300" />
                  ) : (
                    <div className="h-8 w-[2px] bg-neutral-200" />
                  )}
                </motion.div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
