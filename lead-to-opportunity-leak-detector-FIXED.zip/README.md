# Lead-to-Opportunity Leak Detector — deploy package

## What was wrong

Your GitHub Pages site (`kartikclarityofficial.github.io/lead-to-opportunity-leak-detector`)
was serving a static placeholder page ("Application Online" + a link to the repo),
not the actual diagnostic tool. The repo only contained that placeholder `index.html`
plus two zip files that were never extracted or wired up — so there was nothing real
for GitHub Pages to serve.

The component itself (`LeakDetector.jsx`) had no bugs — the scoring engine and all
five views were solid. It just wasn't packaged into something a static host could run:
it was a bare React component expecting `lucide-react` + a bundler that didn't exist
in the repo.

## What's in this zip

```
index.html            ← the page GitHub Pages serves
assets/
  app.bundle.js        ← React + ReactDOM + the app, pre-built and minified
  styles.css           ← compiled, purged Tailwind CSS (only classes actually used)
src/
  app.jsx               ← readable, unminified source — edit this, then rebuild
```

Everything the browser loads (`app.bundle.js`, `styles.css`) is **fully self-contained**.
There are no CDN calls, no `lucide-react` dependency, no runtime Babel/JSX compilation,
and no build step required to deploy it. This was deliberate: it removes every point
where a third-party CDN outage, ad-blocker, or missing package could break the site.
It's already been tested end-to-end in a real headless browser (full 17-question
diagnostic, all five views, the ⌘K command palette, mobile viewport) with zero
console errors.

## How to deploy (fixes the live site)

1. Go to your repo: `kartikclarityofficial/lead-to-opportunity-leak-detector`
2. Delete (or rename) the existing `index.html` at the repo root — it's the placeholder.
3. Upload/add, in this exact structure, at the repo root:
   - `index.html`
   - `assets/app.bundle.js`
   - `assets/styles.css`
   - (optionally) `src/app.jsx` for future maintenance — it isn't loaded at runtime
4. Commit to `main`. GitHub Pages will redeploy automatically within a minute or two.
5. Reload `https://kartikclarityofficial.github.io/lead-to-opportunity-leak-detector/`

You can leave the two old `.zip` files in the repo or delete them — they're not
referenced by anything and won't affect the site either way.

## If you want to edit the app later

Edit `src/app.jsx` (plain JSX, React hooks in scope as `useState` etc. — no imports
needed since it's written as a script, not a module). Then rebuild the bundle with
esbuild and Tailwind:

```bash
npm install esbuild react react-dom tailwindcss@3
npx esbuild src/app.jsx --bundle --minify --format=iife --jsx=transform \
  --target=es2018 --define:process.env.NODE_ENV='"production"' \
  --outfile=assets/app.bundle.js
npx tailwindcss -i tailwind.input.css -o assets/styles.css --minify \
  --content src/app.jsx
```

(`tailwind.input.css` just needs the three standard `@tailwind base/components/utilities`
directives.)
