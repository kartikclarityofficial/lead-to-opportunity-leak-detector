import React from 'react';
import { createRoot } from 'react-dom/client';
import LeakDetectorApp from './LeakDetector.jsx';
import './styles.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LeakDetectorApp />
  </React.StrictMode>
);
