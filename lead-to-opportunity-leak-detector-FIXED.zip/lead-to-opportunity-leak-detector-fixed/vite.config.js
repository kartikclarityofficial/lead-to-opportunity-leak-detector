import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// GitHub Pages project site:
// https://kartikclarityofficial.github.io/lead-to-opportunity-leak-detector/
export default defineConfig({
  plugins: [react()],
  base: '/lead-to-opportunity-leak-detector/',
});
