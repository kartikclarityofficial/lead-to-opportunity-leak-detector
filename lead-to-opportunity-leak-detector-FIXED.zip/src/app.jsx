import React from 'react';
import ReactDOM from 'react-dom/client';

/* ----------------------------------------------------------------------
   Lead-to-Opportunity Leak Detector
   Self-contained React app. No build step required.
   React + ReactDOM + Babel (JSX transform) are loaded via <script> tags
   in index.html. This file is loaded as type="text/babel".
---------------------------------------------------------------------- */
const { useState, useEffect, useCallback, useMemo, useRef, Component } = React;

/* ----------------------------------------------------------------------
   ICONS — small inline SVG components (Feather/Lucide-style, 24x24,
   stroke-based). Self-contained so the app has zero external icon
   dependency and can never fail to load an icon library.
---------------------------------------------------------------------- */
function Icon({ children, className, ...props }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width="24"
      height="24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      focusable="false"
      {...props}
    >
      {children}
    </svg>
  );
}
const ArrowRight = (props) => (
  <Icon {...props}><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></Icon>
);
const ArrowLeft = (props) => (
  <Icon {...props}><path d="M19 12H5" /><path d="m12 19-7-7 7-7" /></Icon>
);
const Search = (props) => (
  <Icon {...props}><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></Icon>
);
const AlertTriangle = (props) => (
  <Icon {...props}>
    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
    <path d="M12 9v4" />
    <path d="M12 17h.01" />
  </Icon>
);
const CheckCircle2 = (props) => (
  <Icon {...props}><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></Icon>
);
const AlertCircle = (props) => (
  <Icon {...props}>
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="8" x2="12" y2="12" />
    <line x1="12" y1="16" x2="12.01" y2="16" />
  </Icon>
);
const TrendingDown = (props) => (
  <Icon {...props}>
    <polyline points="22 17 13.5 8.5 8.5 13.5 2 7" />
    <polyline points="16 17 22 17 22 11" />
  </Icon>
);
const Target = (props) => (
  <Icon {...props}>
    <circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" />
  </Icon>
);
const Activity = (props) => (
  <Icon {...props}><polyline points="22 12 18 12 15 21 9 3 6 12 2 12" /></Icon>
);
const Zap = (props) => (
  <Icon {...props}><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></Icon>
);
const Home = (props) => (
  <Icon {...props}>
    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    <polyline points="9 22 9 12 15 12 15 22" />
  </Icon>
);
const FileText = (props) => (
  <Icon {...props}>
    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5z" />
    <polyline points="14 2 14 8 20 8" />
    <line x1="16" y1="13" x2="8" y2="13" />
    <line x1="16" y1="17" x2="8" y2="17" />
    <line x1="10" y1="9" x2="8" y2="9" />
  </Icon>
);
const BarChart3 = (props) => (
  <Icon {...props}>
    <path d="M3 3v18h18" /><path d="M18 17V9" /><path d="M13 17V5" /><path d="M8 17v-3" />
  </Icon>
);
const X = (props) => (
  <Icon {...props}><path d="M18 6 6 18" /><path d="m6 6 12 12" /></Icon>
);

/* ----------------------------------------------------------------------
   DATA: questions
---------------------------------------------------------------------- */
const QUESTIONS = [
  { id: 'lead-scoring', stage: 'lead', text: 'Are leads scored consistently using explicit criteria?', context: 'Inconsistent lead scoring creates unpredictable qualification outcomes and wastes sales capacity on poor-fit opportunities.', options: ['Never', 'Rarely', 'Sometimes', 'Usually', 'Always'], weight: 8 },
  { id: 'icp-criteria', stage: 'lead', text: 'Are ideal customer profile (ICP) criteria explicitly documented and enforced?', context: 'Without clear ICP criteria, marketing and sales optimize for different definitions of quality.', options: ['No criteria', 'Informal only', 'Documented but not enforced', 'Documented and usually enforced', 'Strictly enforced'], weight: 9 },
  { id: 'mql-quality', stage: 'lead', text: 'What percentage of marketing-qualified leads are genuinely sales-ready?', context: 'MQL inflation damages sales trust and creates preventable disqualification.', options: ['Less than 20%', '20-40%', '40-60%', '60-80%', 'More than 80%'], weight: 10 },
  { id: 'qualification-standard', stage: 'qualification', text: 'Is qualification standardized across all sales reps?', context: 'Qualification variance creates inconsistent pipeline quality and makes forecasting unreliable.', options: ['No standard', 'Informal guidance', 'Written standard but inconsistent', 'Mostly standardized', 'Fully standardized'], weight: 10 },
  { id: 'disqualification-criteria', stage: 'qualification', text: 'Are disqualification criteria clear and consistently applied?', context: 'Without clear disqualification rules, weak opportunities consume disproportionate sales capacity.', options: ['No criteria', 'Unclear criteria', 'Clear but inconsistent', 'Clear and usually applied', 'Clear and strictly applied'], weight: 9 },
  { id: 'business-impact', stage: 'qualification', text: 'Do reps qualify based on measurable business impact, not just interest?', context: 'Interest-based qualification creates bloated pipelines. Impact-based qualification predicts revenue.', options: ['Rarely', 'Sometimes', 'Often', 'Usually', 'Always'], weight: 10 },
  { id: 'decision-maker', stage: 'qualification', text: 'Are decision-makers identified before qualification?', context: 'Opportunities without decision-maker access stall predictably.', options: ['Rarely', 'Sometimes', 'Often', 'Usually', 'Always'], weight: 8 },
  { id: 'contact-speed', stage: 'conversation', text: 'How quickly are qualified leads contacted by sales?', context: 'Contact speed directly impacts conversion. Leads contacted within 5 minutes convert far higher than those contacted after 30 minutes.', options: ['More than 48 hours', '24-48 hours', '4-24 hours', '1-4 hours', 'Within 1 hour'], weight: 9 },
  { id: 'followup-system', stage: 'conversation', text: 'Are follow-ups systematically triggered and tracked?', context: 'Manual follow-up creates leakage. Systematic follow-up prevents it.', options: ['No system', 'Manual tracking', 'Partially automated', 'Mostly automated', 'Fully systematic'], weight: 7 },
  { id: 'next-steps', stage: 'conversation', text: 'Do first conversations consistently produce clear next steps?', context: 'Conversations without concrete next steps rarely progress to opportunities.', options: ['Rarely', 'Sometimes', 'Often', 'Usually', 'Always'], weight: 9 },
  { id: 'pain-discovery', stage: 'conversation', text: 'Is specific business pain established in initial conversations?', context: 'Solutions without established pain create low-urgency opportunities that stall.', options: ['Rarely', 'Sometimes', 'Often', 'Usually', 'Always'], weight: 10 },
  { id: 'urgency', stage: 'conversation', text: 'Is urgency uncovered and validated during initial conversations?', context: 'Opportunities without urgency extend sales cycles unpredictably.', options: ['Rarely', 'Sometimes', 'Often', 'Usually', 'Always'], weight: 8 },
  { id: 'conversation-to-meeting', stage: 'meeting', text: 'What percentage of qualified conversations result in scheduled meetings?', context: 'Low conversion suggests qualification criteria may not match actual buyer readiness.', options: ['Less than 20%', '20-40%', '40-60%', '60-80%', 'More than 80%'], weight: 9 },
  { id: 'meeting-stakeholders', stage: 'meeting', text: 'Are meetings consistently accepted by relevant stakeholders?', context: 'Meetings with wrong stakeholders delay opportunity progression.', options: ['Rarely', 'Sometimes', 'Often', 'Usually', 'Always'], weight: 8 },
  { id: 'opportunity-criteria', stage: 'opportunity', text: 'Is opportunity creation based on validated buying signals?', context: 'Creating opportunities too early inflates pipeline. Too late compresses sales cycles unnecessarily.', options: ['No clear criteria', 'Informal criteria', 'Documented, inconsistent use', 'Clear criteria, usually followed', 'Strict validated criteria'], weight: 10 },
  { id: 'opportunity-timing', stage: 'opportunity', text: 'Are opportunities created at the right stage of buyer readiness?', context: 'Timing affects forecast accuracy and sales efficiency.', options: ['Often too early', 'Sometimes too early', 'Usually appropriate', 'Always appropriate', 'Validated timing process'], weight: 8 },
  { id: 'stalled-visibility', stage: 'opportunity', text: 'Are stalled opportunities quickly identified and addressed?', context: 'Stalled opportunities that remain in pipeline damage forecast accuracy and hide capacity problems.', options: ['Not tracked', 'Tracked informally', 'Tracked but slow response', 'Addressed within 2 weeks', 'Systematic stall protocols'], weight: 7 },
];

const STAGES = [
  { id: 'lead', label: 'Lead' },
  { id: 'qualification', label: 'Qualification' },
  { id: 'conversation', label: 'Conversation' },
  { id: 'meeting', label: 'Meeting' },
  { id: 'opportunity', label: 'Opportunity' },
];

const SCALE_VALUES = { 0: 0, 1: 25, 2: 50, 3: 75, 4: 100 };

/* ----------------------------------------------------------------------
   SCORING ENGINE (deterministic, no black box)
---------------------------------------------------------------------- */
function calculateStageScore(signals) {
  if (signals.length === 0) return 50;
  const totalWeight = signals.reduce((s, x) => s + x.weight, 0);
  const weighted = signals.reduce((s, x) => s + SCALE_VALUES[x.answer] * x.weight, 0);
  return Math.round(weighted / totalWeight);
}

const MECHANISM = {
  'lead-qualification': 'Inconsistent lead qualification criteria or an unclear ICP definition is letting sales engage with poor-fit prospects.',
  'qualification-conversation': 'Qualified leads are not being contacted quickly enough, or initial outreach is failing to establish value.',
  'conversation-meeting': 'Discovery conversations are not producing concrete next steps or failing to establish urgency.',
  'meeting-opportunity': 'Meetings are occurring with the wrong stakeholders, or without validated buying signals.',
};
const IMPLICATION = {
  'lead-qualification': 'Sales capacity is wasted on unqualified prospects — pipeline looks healthy but hides low-quality opportunities.',
  'qualification-conversation': 'Qualified demand loses interest before sales engagement, a real disadvantage in fast-moving markets.',
  'conversation-meeting': 'Sales conversations fail to build urgency; opportunities stay uncommitted and cycle time extends.',
  'meeting-opportunity': 'Meeting activity is high but pipeline growth is low — an inefficient use of prospect and sales time.',
};
const RECOMMENDATION = {
  'lead-qualification': 'Standardize qualification criteria before sales acceptance.',
  'qualification-conversation': 'Implement systematic rapid-response contact protocols.',
  'conversation-meeting': 'Establish required next-step criteria for every discovery call.',
  'meeting-opportunity': 'Define validated buying signals required for opportunity creation.',
};
const FIRST_MOVE = {
  'lead-qualification': 'Document your ICP as a 5-point checklist. Require sales to confirm fit before accepting a lead.',
  'qualification-conversation': 'Set a 4-hour maximum response time for qualified leads. Track and report violations.',
  'conversation-meeting': 'Add a required next-step field in your CRM. No conversation closes without it.',
  'meeting-opportunity': 'Define three mandatory buying signals. No opportunity is created without all three validated.',
};
const STAGE_FIRST_MOVE = {
  lead: 'Audit the last 50 leads against your stated ICP. Calculate the match rate.',
  qualification: 'Review the last 20 qualified opportunities. Identify which should have been disqualified.',
  conversation: 'Record the next 10 discovery calls. Score them against a standardized framework.',
  meeting: 'Track meeting-to-opportunity conversion per rep. Identify outliers.',
  opportunity: 'Review opportunities created in the last 30 days. Validate that buying signals were present.',
};
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

function calculateDiagnostic(answers) {
  const signals = Object.entries(answers).map(([questionId, answer]) => {
    const q = QUESTIONS.find((q) => q.id === questionId);
    if (!q) return null;
    const numeric = SCALE_VALUES[answer];
    const impact = numeric >= 75 ? 'positive' : numeric <= 25 ? 'negative' : 'neutral';
    return { questionId, answer, impact, weight: q.weight, stage: q.stage };
  }).filter(Boolean);

  const stageHealth = STAGES.map(({ id }) => {
    const stageSignals = signals.filter((s) => s.stage === id);
    return { stage: id, score: calculateStageScore(stageSignals), signals: stageSignals };
  });

  const overallScore = Math.round(stageHealth.reduce((s, x) => s + x.score, 0) / stageHealth.length);
  const healthBand =
    overallScore >= 85 ? 'strong' : overallScore >= 70 ? 'healthy' : overallScore >= 50 ? 'leakage' : 'critical';

  const leaks = [];
  for (let i = 0; i < STAGES.length - 1; i++) {
    const cur = stageHealth[i];
    const next = stageHealth[i + 1];
    const drop = cur.score - next.score;
    const avg = (cur.score + next.score) / 2;
    if (drop > 15 || avg < 60) {
      const severity =
        drop > 30 || avg < 40 ? 'critical' : drop > 20 || avg < 50 ? 'high' : drop > 10 || avg < 60 ? 'moderate' : 'low';
      const key = `${cur.stage}-${next.stage}`;
      leaks.push({
        from: cur.stage,
        to: next.stage,
        severity,
        signals: [...cur.signals, ...next.signals].filter((s) => s.impact === 'negative'),
        explanation: `${severity === 'critical' ? 'Critical momentum loss' : severity === 'high' ? 'Significant friction' : severity === 'moderate' ? 'Observable friction' : 'Minor friction'} detected between ${cap(cur.stage)} and ${cap(next.stage)}. Qualified demand is not converting efficiently to the next stage.`,
        mechanism: MECHANISM[key] || 'Process friction is preventing natural stage progression.',
        implication: IMPLICATION[key] || 'Revenue predictability and sales efficiency are negatively impacted.',
        recommendation: RECOMMENDATION[key] || 'Review and standardize stage transition requirements.',
        firstMove: FIRST_MOVE[key] || 'Audit the current process and identify the top 3 friction points.',
      });
    }
  }

  const severityOrder = { critical: 4, high: 3, moderate: 2, low: 1 };
  const primaryLeak = [...leaks].sort((a, b) => severityOrder[b.severity] - severityOrder[a.severity])[0] || null;

  const recs = [];
  leaks.forEach((leak) => {
    const priority = leak.severity === 'critical' ? 'critical' : leak.severity === 'high' ? 'high' : leak.severity === 'moderate' ? 'medium' : 'low';
    recs.push({ action: leak.recommendation, why: leak.mechanism, priority, expectedEffect: `Reduce leakage between ${cap(leak.from)} and ${cap(leak.to)}.`, firstMove: leak.firstMove });
  });
  stageHealth.forEach((sh) => {
    if (sh.score < 60) {
      recs.push({
        action: `Strengthen ${cap(sh.stage)} stage processes`,
        why: `${cap(sh.stage)} diagnostic score indicates structural process weakness.`,
        priority: sh.score < 40 ? 'critical' : sh.score < 50 ? 'high' : 'medium',
        expectedEffect: `Improve overall ${cap(sh.stage)} health and downstream conversion.`,
        firstMove: STAGE_FIRST_MOVE[sh.stage],
      });
    }
  });
  const pOrder = { critical: 4, high: 3, medium: 2, low: 1 };
  const recommendations = recs.sort((a, b) => pOrder[b.priority] - pOrder[a.priority]).slice(0, 5);

  return { overallScore, healthBand, leaks, primaryLeak, stageHealth, recommendations, signals };
}

/* ----------------------------------------------------------------------
   VISUAL TOKENS (mapped to Tailwind core palette — no config extension)
---------------------------------------------------------------------- */
const SEVERITY_STYLE = {
  critical: { text: 'text-red-700', bg: 'bg-red-50', border: 'border-red-600', dot: 'bg-red-600' },
  high: { text: 'text-orange-700', bg: 'bg-orange-50', border: 'border-orange-600', dot: 'bg-orange-600' },
  moderate: { text: 'text-amber-700', bg: 'bg-amber-50', border: 'border-amber-500', dot: 'bg-amber-500' },
  low: { text: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-500', dot: 'bg-emerald-500' },
};
const BAND_STYLE = {
  strong: { text: 'text-emerald-700', label: 'Strong' },
  healthy: { text: 'text-lime-700', label: 'Healthy with friction' },
  leakage: { text: 'text-orange-700', label: 'Leakage detected' },
  critical: { text: 'text-red-700', label: 'Critical leakage' },
};

/* ----------------------------------------------------------------------
   COMMAND PALETTE
---------------------------------------------------------------------- */
function CommandPalette({ open, onClose, commands }) {
  const [search, setSearch] = useState('');
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) {
      setSearch('');
      setTimeout(() => inputRef.current?.focus(), 10);
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    if (open) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;
  const filtered = commands.filter((c) => c.label.toLowerCase().includes(search.toLowerCase()));

  return (
    <div
      className="fixed inset-0 bg-neutral-900/50 z-50 flex items-start justify-center pt-24 px-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Command palette"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white rounded-md shadow-2xl overflow-hidden border border-neutral-200"
      >
        <div className="flex items-center gap-3 px-4 py-3 border-b border-neutral-200">
          <Search className="w-4 h-4 text-neutral-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Jump to..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 outline-none text-sm text-neutral-900 placeholder:text-neutral-400"
          />
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-neutral-100 text-neutral-500 rounded">ESC</kbd>
        </div>
        <div className="max-h-72 overflow-y-auto">
          {filtered.length === 0 && (
            <div className="px-4 py-6 text-sm text-neutral-400 text-center">No matching command.</div>
          )}
          {filtered.map((cmd, i) => (
            <button
              key={cmd.id}
              onClick={() => { cmd.action(); onClose(); }}
              disabled={cmd.disabled}
              className={`w-full flex items-center justify-between px-4 py-2.5 text-left text-sm transition-colors ${i !== 0 ? 'border-t border-neutral-100' : ''} ${cmd.disabled ? 'text-neutral-300 cursor-not-allowed' : 'text-neutral-800 hover:bg-neutral-50'}`}
            >
              <span className="font-medium">{cmd.label}</span>
              <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-neutral-100 text-neutral-500 rounded">{cmd.shortcut}</kbd>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------
   LEAK MAP — signature visual: stages joined by "conduits" that drip
   at leak points. Vertical on narrow widths, horizontal from sm up.
---------------------------------------------------------------------- */
function LeakMap({ result }) {
  const getStatus = (stageId) => {
    if (!result) return 'default';
    const sh = result.stageHealth.find((s) => s.stage === stageId);
    if (!sh) return 'default';
    const isLeak = result.leaks.some((l) => l.from === stageId || l.to === stageId);
    if (isLeak) return 'leak';
    if (sh.score >= 75) return 'strong';
    if (sh.score >= 60) return 'healthy';
    return 'watch';
  };
  const getConn = (from, to) => {
    if (!result) return 'default';
    const l = result.leaks.find((l) => l.from === from && l.to === to);
    return l ? l.severity : 'healthy';
  };

  const stageBoxClass = (status) => {
    switch (status) {
      case 'leak': return 'border-orange-500 bg-orange-50';
      case 'strong': return 'border-emerald-300 bg-emerald-50/60';
      case 'healthy': return 'border-neutral-300 bg-neutral-100';
      case 'watch': return 'border-amber-300 bg-amber-50/60';
      default: return 'border-neutral-200 bg-white';
    }
  };

  return (
    <div className="w-full">
      <style>{`
        @keyframes drip { 0% { transform: translateY(0); opacity: 0.9; } 100% { transform: translateY(14px); opacity: 0; } }
        .drip-dot { animation: drip 1.4s ease-in infinite; }
        @media (prefers-reduced-motion: reduce) { .drip-dot { animation: none; } }
      `}</style>
      <div className="flex flex-col sm:flex-row sm:items-stretch gap-0">
        {STAGES.map((stage, i) => {
          const status = getStatus(stage.id);
          const next = STAGES[i + 1];
          const conn = next ? getConn(stage.id, next.id) : null;
          const sh = result?.stageHealth.find((s) => s.stage === stage.id);
          return (
            <React.Fragment key={stage.id}>
              <div className={`relative flex-1 px-4 py-4 text-center border-2 rounded-sm ${stageBoxClass(status)}`}>
                <div className="text-[10px] font-mono text-neutral-400 mb-1">{String(i + 1).padStart(2, '0')}</div>
                <div className="font-semibold text-xs tracking-wide uppercase text-neutral-800">{stage.label}</div>
                {result && (
                  <div className="mt-1.5 flex items-center justify-center gap-1">
                    {status === 'leak' && <AlertTriangle className="w-3.5 h-3.5 text-orange-600" />}
                    {status === 'strong' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                    {status === 'watch' && <AlertCircle className="w-3.5 h-3.5 text-amber-500" />}
                    <span className="text-xs font-mono text-neutral-600">{sh?.score ?? '--'}</span>
                  </div>
                )}
              </div>
              {next && (
                <div className="flex sm:flex-col items-center justify-center relative shrink-0 h-6 sm:h-auto sm:w-10">
                  {conn === 'critical' || conn === 'high' ? (
                    <div className="relative w-full sm:w-[2px] h-[2px] sm:h-full bg-gradient-to-r sm:bg-gradient-to-b from-orange-500 to-orange-200">
                      <div className="drip-dot absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-orange-500" />
                    </div>
                  ) : conn === 'moderate' ? (
                    <div className="w-full sm:w-[2px] h-[2px] sm:h-full bg-gradient-to-r sm:bg-gradient-to-b from-amber-400 to-neutral-200" />
                  ) : (
                    <div className="w-full sm:w-[2px] h-[2px] sm:h-full bg-neutral-200" />
                  )}
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------
   VIEWS
---------------------------------------------------------------------- */
function HomeView({ onStart, onMethod, result }) {
  return (
    <div className="max-w-4xl mx-auto px-4 py-14 sm:py-20">
      <div className="text-center mb-14">
        <div className="inline-block mb-5 px-3 py-1 border border-neutral-300 rounded-sm text-[11px] font-mono tracking-widest text-neutral-500 uppercase">
          Revenue diagnostic instrument
        </div>
        <h1 className="text-4xl sm:text-6xl font-bold tracking-tight text-neutral-900 mb-5 leading-[1.05]">
          Lead <span className="text-neutral-300">→</span> Opportunity<br className="hidden sm:block" /> Leak Detector
        </h1>
        <p className="text-lg sm:text-xl text-neutral-500 max-w-xl mx-auto mb-9">
          Find where qualified demand disappears before it becomes pipeline.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
          <button
            onClick={onStart}
            className="group px-7 py-3.5 bg-neutral-900 text-white rounded-sm font-medium hover:bg-neutral-800 transition-colors flex items-center gap-2"
          >
            Run the diagnostic
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </button>
          <button
            onClick={onMethod}
            className="px-7 py-3.5 border border-neutral-300 text-neutral-800 rounded-sm font-medium hover:border-neutral-400 transition-colors"
          >
            Explore the method
          </button>
        </div>
      </div>

      <LeakMap result={result} />

      <div className="mt-14 text-center">
        <p className="text-neutral-400 text-sm mb-1">Your CRM tells you what happened.</p>
        <p className="text-neutral-900 font-medium">This tells you where opportunity is leaking.</p>
      </div>
    </div>
  );
}

function DiagnosticView({ index, answers, onAnswer, onNext, onPrev }) {
  const question = QUESTIONS[index];
  const progress = ((index + 1) / QUESTIONS.length) * 100;
  const selected = answers[question.id];

  return (
    <div className="max-w-2xl mx-auto px-4 py-10 sm:py-14">
      <div className="mb-9">
        <div className="flex items-center justify-between text-xs font-mono text-neutral-500 mb-2">
          <span>Q{index + 1} / {QUESTIONS.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-1 bg-neutral-200 rounded-full overflow-hidden">
          <div className="h-full bg-neutral-900 transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div key={question.id}>
        <span className="inline-block mb-3 px-2.5 py-1 bg-neutral-100 text-neutral-600 text-[10px] font-mono uppercase tracking-widest rounded-sm">
          {question.stage}
        </span>
        <h2 className="text-2xl sm:text-3xl font-bold text-neutral-900 mb-3 leading-snug">{question.text}</h2>
        <p className="text-neutral-500 mb-7 leading-relaxed">{question.context}</p>

        <div className="space-y-2.5 mb-9" role="radiogroup" aria-label={question.text}>
          {question.options.map((opt, i) => (
            <button
              key={i}
              role="radio"
              aria-checked={selected === i}
              onClick={() => onAnswer(question.id, i)}
              className={`w-full px-5 py-3.5 text-left rounded-sm border-2 transition-colors flex items-center justify-between ${
                selected === i ? 'border-neutral-900 bg-neutral-900 text-white' : 'border-neutral-200 bg-white hover:border-neutral-400'
              }`}
            >
              <span className="font-medium text-sm">{opt}</span>
              <div className={`w-4 h-4 rounded-full border-2 shrink-0 ${selected === i ? 'border-white bg-white' : 'border-neutral-300'}`} />
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between pt-6 border-t border-neutral-200">
          <button
            onClick={onPrev}
            disabled={index === 0}
            className="flex items-center gap-2 px-4 py-2.5 text-sm text-neutral-600 hover:text-neutral-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Previous
          </button>
          <button
            onClick={onNext}
            disabled={selected === undefined}
            className="flex items-center gap-2 px-6 py-2.5 bg-neutral-900 text-white rounded-sm text-sm font-medium hover:bg-neutral-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
          >
            {index === QUESTIONS.length - 1 ? 'Complete diagnostic' : 'Next question'} <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

function AnalyzingView() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center px-4">
      <div className="text-center">
        <div className="w-10 h-10 border-2 border-neutral-900 border-t-transparent rounded-full mx-auto mb-5 animate-spin motion-reduce:animate-none" />
        <p className="text-lg font-medium text-neutral-900">Analyzing diagnostic responses</p>
        <p className="text-neutral-400 text-sm mt-1">Mapping leakage points across the funnel...</p>
      </div>
    </div>
  );
}

function ResultsView({ result, onReset, onMethod }) {
  const band = BAND_STYLE[result.healthBand];
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 pb-20">
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-2">Diagnostic results</h1>
        <p className="text-neutral-500">Your lead-to-opportunity assessment is complete.</p>
      </div>

      <div className="mb-12 text-center">
        <div className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-2">Lead-to-opportunity health</div>
        <div className={`text-7xl sm:text-8xl font-bold leading-none ${band.text}`}>{result.overallScore}</div>
        <div className="text-lg font-medium text-neutral-600 mt-3">{band.label}</div>
      </div>

      {result.primaryLeak && (
        <div className={`mb-12 p-6 sm:p-7 border-2 rounded-sm ${SEVERITY_STYLE[result.primaryLeak.severity].border} ${SEVERITY_STYLE[result.primaryLeak.severity].bg}`}>
          <div className="flex items-start gap-4">
            <AlertTriangle className={`w-5 h-5 shrink-0 mt-1 ${SEVERITY_STYLE[result.primaryLeak.severity].text}`} />
            <div className="flex-1 min-w-0">
              <div className={`text-xs font-mono uppercase tracking-widest mb-2 ${SEVERITY_STYLE[result.primaryLeak.severity].text}`}>Primary leak detected</div>
              <div className="text-xl font-bold text-neutral-900 mb-2">{cap(result.primaryLeak.from)} → {cap(result.primaryLeak.to)}</div>
              <p className="text-neutral-700 mb-3 text-sm leading-relaxed">{result.primaryLeak.explanation}</p>
              <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 border rounded-sm text-xs font-mono font-medium ${SEVERITY_STYLE[result.primaryLeak.severity].border} ${SEVERITY_STYLE[result.primaryLeak.severity].text}`}>
                <TrendingDown className="w-3.5 h-3.5" /> {result.primaryLeak.severity.toUpperCase()} SEVERITY
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="mb-14">
        <h2 className="text-xl font-bold text-neutral-900 mb-6 text-center">Diagnostic map</h2>
        <LeakMap result={result} />
      </div>

      {result.leaks.length > 0 && (
        <div className="mb-14">
          <h2 className="text-xl font-bold text-neutral-900 mb-5">Detected leaks</h2>
          <div className="space-y-5">
            {result.leaks.map((leak, i) => {
              const s = SEVERITY_STYLE[leak.severity];
              return (
                <div key={i} className="border border-neutral-200 rounded-sm p-5 sm:p-6">
                  <div className="mb-4">
                    <div className="text-lg font-bold text-neutral-900 mb-1.5">{cap(leak.from)} → {cap(leak.to)}</div>
                    <span className={`inline-block px-2 py-0.5 border rounded-sm text-[10px] font-mono font-medium ${s.border} ${s.text}`}>{leak.severity.toUpperCase()}</span>
                  </div>
                  <div className="space-y-3 text-sm">
                    <div><div className="font-semibold text-neutral-900 mb-0.5">What this means</div><p className="text-neutral-600">{leak.explanation}</p></div>
                    <div><div className="font-semibold text-neutral-900 mb-0.5">Likely mechanism</div><p className="text-neutral-600">{leak.mechanism}</p></div>
                    <div><div className="font-semibold text-neutral-900 mb-0.5">Business implication</div><p className="text-neutral-600">{leak.implication}</p></div>
                    <div className="pt-3 border-t border-neutral-100"><span className="text-xs text-neutral-400">{leak.signals.length} signal{leak.signals.length !== 1 ? 's' : ''} contributed to this diagnosis</span></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {result.recommendations.length > 0 && (
        <div className="mb-14">
          <h2 className="text-xl font-bold text-neutral-900 mb-5">Recommended actions</h2>
          <div className="space-y-3">
            {result.recommendations.map((rec, i) => {
              const pStyle = {
                critical: 'bg-red-50 text-red-700', high: 'bg-orange-50 text-orange-700',
                medium: 'bg-amber-50 text-amber-700', low: 'bg-neutral-100 text-neutral-600',
              }[rec.priority];
              return (
                <div key={i} className="p-5 border border-neutral-200 rounded-sm">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="font-bold text-neutral-900 text-sm leading-snug">{rec.action}</div>
                    <span className={`px-2 py-0.5 text-[10px] font-mono uppercase tracking-wide rounded-sm shrink-0 ${pStyle}`}>{rec.priority}</span>
                  </div>
                  <div className="space-y-2 text-sm">
                    <p className="text-neutral-600">{rec.why}</p>
                    <div className="pt-2 border-t border-neutral-100">
                      <div className="text-xs font-semibold text-neutral-500 uppercase tracking-wide mb-0.5">First move</div>
                      <p className="text-neutral-800 font-medium">{rec.firstMove}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="mb-12 p-7 bg-neutral-900 text-white rounded-sm">
        <p className="text-neutral-400 text-xs font-mono uppercase tracking-widest mb-2">Diagnostic insight</p>
        <p className="text-lg leading-relaxed">
          Your funnel isn't necessarily short on leads. The diagnostic indicates the larger issue may be what happens after{' '}
          {result.primaryLeak ? cap(result.primaryLeak.from) : 'qualification'}.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <button onClick={onReset} className="px-7 py-3 border border-neutral-300 text-neutral-800 rounded-sm font-medium hover:border-neutral-400 transition-colors">
          Run new diagnostic
        </button>
        <button onClick={onMethod} className="px-7 py-3 bg-neutral-900 text-white rounded-sm font-medium hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2">
          Read the method <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function MethodView() {
  const steps = [
    { icon: Target, stage: 'Lead', description: 'Raw demand enters the system.' },
    { icon: Search, stage: 'Qualification', description: 'Demand is validated against ICP criteria.' },
    { icon: Activity, stage: 'Conversation', description: 'Sales engages and establishes value.' },
    { icon: Zap, stage: 'Meeting', description: 'Stakeholders commit time.' },
    { icon: TrendingDown, stage: 'Opportunity', description: 'Validated buying intent creates pipeline.' },
  ];
  const how = [
    ['Diagnostic assessment', 'A structured set of questions examines process quality, speed, standardization, and signal validation at each stage.'],
    ['Signal collection', 'Each response generates a diagnostic signal. Signals are weighted by their predictive importance to stage health.'],
    ['Stage health calculation', 'Signals within a stage combine into a 0–100 health score reflecting process maturity and execution quality.'],
    ['Leak detection', 'Transitions where stage health drops sharply, or where average health falls below threshold, are classified as leaks.'],
    ['Evidence mapping', 'Every leak is tied back to the specific responses that triggered it, for a transparent evidence trail.'],
    ['Recommendation generation', 'Leak severity and stage weakness drive prioritized, actionable recommendations with a concrete first move.'],
  ];
  return (
    <div className="max-w-2xl mx-auto px-4 py-12 pb-20">
      <div className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-bold text-neutral-900 mb-3">The method</h1>
        <p className="text-neutral-500">How the Leak Detector finds hidden revenue loss.</p>
      </div>

      <div className="space-y-10">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 mb-3">The problem</h2>
          <p className="text-neutral-600 leading-relaxed text-sm">
            Most revenue teams track conversion rates between funnel stages. But conversion rates alone don't reveal why qualified leads
            disappear — they don't show where process breaks down, handoffs fail, or qualification standards weaken. This tool examines
            the operational mechanics between stages to find the specific points where momentum is lost.
          </p>
        </div>

        <div className="p-6 bg-neutral-50 border border-neutral-200 rounded-sm">
          <h3 className="text-sm font-bold text-neutral-900 mb-5 uppercase tracking-wide">The five-stage journey</h3>
          <div className="space-y-5">
            {steps.map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="flex items-start gap-3.5">
                  <div className="w-9 h-9 bg-white border border-neutral-200 rounded-sm flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-neutral-600" />
                  </div>
                  <div>
                    <div className="font-bold text-sm text-neutral-900">{s.stage}</div>
                    <div className="text-sm text-neutral-500">{s.description}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-bold text-neutral-900 mb-4">How it works</h2>
          <div className="space-y-4">
            {how.map(([title, body], i) => (
              <div key={i}>
                <h3 className="font-semibold text-sm text-neutral-900 mb-1">{i + 1}. {title}</h3>
                <p className="text-sm text-neutral-600 leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 bg-neutral-900 text-white rounded-sm">
          <h3 className="font-bold mb-3 text-sm uppercase tracking-wide">What makes this different</h3>
          <ul className="space-y-2 text-sm">
            {[
              'Diagnostic focus on why leaks occur, not just that they exist',
              'Evidence-based findings tied to specific operational signals',
              'Severity classification to prioritize limited improvement capacity',
              'Actionable recommendations with a concrete first move',
              'No CRM integration required — the diagnostic runs independently',
            ].map((t, i) => (
              <li key={i} className="flex items-start gap-2.5">
                <div className="w-1 h-1 bg-white rounded-full mt-2 shrink-0" />
                <span className="text-neutral-200">{t}</span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="text-lg font-bold text-neutral-900 mb-3">Important limitations</h2>
          <p className="text-neutral-600 leading-relaxed text-sm mb-3">
            This diagnostic is <strong>not</strong> a predictive model. It does not analyze actual CRM data, and it does not guarantee
            specific revenue outcomes.
          </p>
          <p className="text-neutral-600 leading-relaxed text-sm">
            It is a <strong>structured assessment framework</strong> that helps revenue leaders systematically examine process health and
            identify likely friction points, based on established sales methodology principles.
          </p>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------
   APP SHELL
---------------------------------------------------------------------- */
function LeakDetectorApp() {
  const [view, setView] = useState('home'); // home | diagnostic | analyzing | results | method
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [paletteOpen, setPaletteOpen] = useState(false);

  const startDiagnostic = useCallback(() => {
    setQIndex(0);
    setAnswers({});
    setResult(null);
    setView('diagnostic');
  }, []);

  const handleAnswer = useCallback((qid, idx) => {
    setAnswers((prev) => ({ ...prev, [qid]: idx }));
  }, []);

  const handleNext = useCallback(() => {
    if (qIndex < QUESTIONS.length - 1) {
      setQIndex((i) => i + 1);
    } else {
      setView('analyzing');
    }
  }, [qIndex]);

  const handlePrev = useCallback(() => setQIndex((i) => Math.max(0, i - 1)), []);

  useEffect(() => {
    if (view === 'analyzing') {
      const t = setTimeout(() => {
        setResult(calculateDiagnostic(answers));
        setView('results');
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [view, answers]);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const commands = useMemo(() => [
    { id: 'run', label: 'Run diagnostic', action: startDiagnostic, shortcut: 'D' },
    { id: 'results', label: 'View results', action: () => setView('results'), shortcut: 'R', disabled: !result },
    { id: 'reset', label: 'Reset assessment', action: startDiagnostic, shortcut: 'X' },
    { id: 'method', label: 'Explore the method', action: () => setView('method'), shortcut: 'M' },
    { id: 'home', label: 'Go to overview', action: () => setView('home'), shortcut: 'H' },
  ], [startDiagnostic, result]);

  const nav = [
    { id: 'home', label: 'Overview', icon: Home },
    { id: 'diagnostic', label: 'Diagnostic', icon: Activity, action: startDiagnostic },
    { id: 'results', label: 'Results', icon: BarChart3, disabled: !result },
    { id: 'method', label: 'Method', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 font-sans">
      <header className="border-b border-neutral-200 bg-white/90 backdrop-blur sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <button onClick={() => setView('home')} className="flex items-center gap-2.5 hover:opacity-70 transition-opacity">
              <div className="w-6 h-6 bg-neutral-900 rounded-full flex items-center justify-center shrink-0">
                <div className="w-2 h-2 border border-white rounded-full" />
              </div>
              <span className="font-semibold text-sm hidden xs:block">Leak Detector</span>
            </button>

            <nav className="hidden sm:flex items-center gap-1">
              {nav.map((item) => {
                const Icon = item.icon;
                const active = view === item.id || (item.id === 'diagnostic' && view === 'diagnostic');
                return (
                  <button
                    key={item.id}
                    onClick={() => !item.disabled && (item.action ? item.action() : setView(item.id))}
                    disabled={item.disabled}
                    className={`px-3 py-1.5 rounded-sm text-xs font-medium transition-colors flex items-center gap-1.5 ${
                      active ? 'bg-neutral-900 text-white' : item.disabled ? 'text-neutral-300 cursor-not-allowed' : 'text-neutral-600 hover:bg-neutral-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" /> {item.label}
                  </button>
                );
              })}
            </nav>

            <button
              onClick={() => setPaletteOpen(true)}
              className="flex items-center gap-2 px-2.5 py-1.5 border border-neutral-200 rounded-sm text-xs text-neutral-500 hover:border-neutral-300 transition-colors"
              aria-label="Open command palette"
            >
              <Search className="w-3.5 h-3.5" />
              <kbd className="font-mono hidden sm:inline">⌘K</kbd>
            </button>
          </div>
        </div>
      </header>

      <main className="pb-16 sm:pb-0">
        {view === 'home' && <HomeView onStart={startDiagnostic} onMethod={() => setView('method')} result={result} />}
        {view === 'diagnostic' && (
          <DiagnosticView index={qIndex} answers={answers} onAnswer={handleAnswer} onNext={handleNext} onPrev={handlePrev} />
        )}
        {view === 'analyzing' && <AnalyzingView />}
        {view === 'results' && result && <ResultsView result={result} onReset={startDiagnostic} onMethod={() => setView('method')} />}
        {view === 'method' && <MethodView />}
      </main>

      <footer className="hidden sm:block border-t border-neutral-200 bg-white mt-8">
        <div className="max-w-5xl mx-auto px-4 py-8 text-center">
          <div className="inline-block px-3 py-1 border border-neutral-200 text-[10px] font-mono tracking-widest text-neutral-400 uppercase mb-3">
            Lead-to-opportunity leak detector
          </div>
          <p className="text-xs text-neutral-400">A structured revenue diagnostic. Not a predictive model.</p>
        </div>
      </footer>

      <div className="sm:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-200 z-30">
        <nav className="flex items-center justify-around">
          {nav.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                onClick={() => !item.disabled && (item.action ? item.action() : setView(item.id))}
                disabled={item.disabled}
                className={`flex-1 py-2.5 flex flex-col items-center gap-1 text-[10px] transition-colors ${
                  active ? 'text-neutral-900' : item.disabled ? 'text-neutral-300' : 'text-neutral-500'
                }`}
              >
                <Icon className="w-4 h-4" /> {item.label}
              </button>
            );
          })}
        </nav>
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} commands={commands} />
    </div>
  );
}

/* ----------------------------------------------------------------------
   ERROR BOUNDARY — so a single rendering issue shows a recoverable
   message instead of a blank white page.
---------------------------------------------------------------------- */
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error, info) {
    console.error('Leak Detector crashed:', error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center px-4 bg-neutral-50">
          <div className="max-w-md text-center">
            <h1 className="text-xl font-bold text-neutral-900 mb-2">Something went wrong</h1>
            <p className="text-neutral-500 text-sm mb-6">
              The diagnostic hit an unexpected error. Reloading usually fixes it.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 bg-neutral-900 text-white rounded-sm text-sm font-medium hover:bg-neutral-800 transition-colors"
            >
              Reload
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

/* ----------------------------------------------------------------------
   MOUNT
---------------------------------------------------------------------- */
const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(
  <ErrorBoundary>
    <LeakDetectorApp />
  </ErrorBoundary>
);
