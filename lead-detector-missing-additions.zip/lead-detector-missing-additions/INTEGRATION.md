# Integration

## 1. Copy the component
Copy `MissingAdditions.jsx` into the same components directory as `LeakDetector.jsx`.

## 2. Add the import
At the top of `LeakDetector.jsx`:

```jsx
import {
  LeadDetectorMeta,
  ApplicationOnlineStatus,
  RepositoryCTA,
} from './MissingAdditions';
```

Adjust the relative path if needed.

## 3. Add metadata
Inside `LeakDetectorApp()`, place this immediately inside the root return wrapper:

```jsx
<LeadDetectorMeta />
```

Example:

```jsx
return (
  <div className="min-h-screen ...">
    <LeadDetectorMeta />
```

## 4. Add the missing online status
If you want to preserve the standalone HTML's status pill, place:

```jsx
<ApplicationOnlineStatus />
```

above the existing HomeView eyebrow or wherever the deployment status should appear.

## 5. Add the repository CTA
Place:

```jsx
<RepositoryCTA />
```

where you want the "View Repository" action to appear, such as the HomeView CTA area or footer.

No existing diagnostic logic needs to be changed.
