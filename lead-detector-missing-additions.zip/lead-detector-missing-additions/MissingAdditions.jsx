import React from 'react';
import { Github } from 'lucide-react';

/**
 * Optional additions extracted from the supplied standalone HTML.
 * Add these only if you want the JSX application to preserve the
 * missing deployment/landing metadata and repository CTA.
 */

export function LeadDetectorMeta() {
  React.useEffect(() => {
    document.title = 'Lead to Opportunity Leak Detector™';

    let description = document.querySelector('meta[name="description"]');
    if (!description) {
      description = document.createElement('meta');
      description.setAttribute('name', 'description');
      document.head.appendChild(description);
    }
    description.setAttribute('content', 'Lead to Opportunity Leak Detector™');
  }, []);

  return null;
}

export function ApplicationOnlineStatus() {
  return (
    <div className="inline-flex items-center px-3 py-1.5 border border-emerald-200 bg-emerald-50 text-emerald-700 rounded-full text-xs font-medium">
      Application Online
    </div>
  );
}

export function RepositoryCTA() {
  return (
    <a
      href="https://github.com/kartikclarityofficial/lead-to-opportunity-leak-detector"
      target="_blank"
      rel="noreferrer"
      className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-sm border border-neutral-300 text-sm font-medium text-neutral-700 hover:border-neutral-500 hover:text-neutral-950 transition-colors"
    >
      <Github className="w-4 h-4" />
      View Repository
    </a>
  );
}
